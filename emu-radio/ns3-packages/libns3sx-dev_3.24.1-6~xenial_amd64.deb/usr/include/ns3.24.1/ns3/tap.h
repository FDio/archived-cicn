/**
 * \defgroup tap-bridge Tap Bridge Network Device
 *
 * This section documents the API of the ns-3 tap-bridge module. For a
 * generic functional description, please refer to the ns-3 manual.
 */
