/* WARNING! All changes made to this file will be lost! */

#ifndef W_NS3_CONFIG_STORE_CONFIG_H_WAF
#define W_NS3_CONFIG_STORE_CONFIG_H_WAF

#define PYTHONDIR "/usr/lib/python2.7/dist-packages"
#define PYTHONARCHDIR "/usr/lib/python2.7/dist-packages"
#define HAVE_PYEMBED 1
#define HAVE_PYEXT 1
#define HAVE_PYTHON_H 1

#endif /* W_NS3_CONFIG_STORE_CONFIG_H_WAF */
